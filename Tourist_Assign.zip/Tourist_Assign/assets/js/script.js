$(document).ready(function(){
    $('.slick-slider').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,
      arrows: true,
    
     responsive: [
                  {          
                    breakpoint: 480,
                    settings: {
                        mobileFirst: true,
                        infinite: true,
                        slidesToShow: 1
                    }
                  },
                  {
                    breakpoint: 1024,
                    settings: {
                        mobileFirst: true,
                        infinite: true,
                        slidesToShow: 2
                    }
                  }
     ]
    });
  });